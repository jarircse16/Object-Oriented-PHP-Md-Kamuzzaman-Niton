<?php
	class Product{
		protected $date;
		protected $total_pages;
		protected $copyright;
	}
	