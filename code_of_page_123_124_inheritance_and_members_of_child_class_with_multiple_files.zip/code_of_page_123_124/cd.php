<?php
	require_once('product.php');
	class CD extends Product{
		protected $edition;
		protected $editor;
		protected $price;
	}